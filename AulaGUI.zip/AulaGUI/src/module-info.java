/**
 * 
 */
/**
 * 
 */
module AulaGUI {
	requires java.desktop;
}