package InterfaceGUI;

import javax.swing.*;
import java.awt.Container;
import java.text.ParseException;
import javax.swing.text.MaskFormatter;

public class PrimeiraTela extends JFrame {

	private static final long serialVersionUID = -7653037730290231027L;
	
	private JLabel lblNome;
	private JTextField txtNome;
	private JLabel lblCPF;
	private JFormattedTextField txtCPF;
	private JLabel lblTipo;
	private JComboBox cmbTipo;
	private JButton btnOk;
	private Container ctn;
	
	private final String[] tipoUsuarios = { "Admin", "Geral", "Visitante" };
	
	public PrimeiraTela() {
		setSize(400, 300);
		setTitle("Primeira Tela GUI");
		
		ctn = getContentPane();
		lblNome = new JLabel("Nome");
		txtNome = new JTextField();
		lblCPF = new JLabel("CPF");
		
		try {
			txtCPF = new JFormattedTextField(new MaskFormatter("###.###.###-##"));
		}catch(ParseException e) {
			e.printStackTrace();
		}
		
		lblTipo = new JLabel("Tipo de usuário");
		cmbTipo = new JComboBox(tipoUsuarios);
		btnOk = new JButton("Ok");
		
		ctn.setLayout(null);
		
		lblNome.setBounds(0,0,100,25);
		txtNome.setBounds(150,0,100,25);
		
		lblCPF.setBounds(0,50,100,25);
		txtCPF.setBounds(150,50,100,25);
		
		lblTipo.setBounds(0,100,120,25);
		cmbTipo.setBounds(150,100,100,25);
		
		btnOk.setBounds(150, 150, 100, 100);
		
		ctn.add(lblNome);
		ctn.add(txtNome);
		ctn.add(lblCPF);
		ctn.add(txtCPF);
		ctn.add(lblTipo);
		ctn.add(cmbTipo);
		ctn.add(btnOk);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PrimeiraTela t1 = new PrimeiraTela();

	}

}
